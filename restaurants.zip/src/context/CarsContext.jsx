// import { createContext, useReducer } from "react";

// export const CarsContext = createContext()

// export const CarsContextProvider = () => {
//     const [state, dispatch] = useReducer(carsReducer, {
//         cars: null
//     })

//     dispatch({type: 'SET_CARS'})

//     return (
//         <CarsContext.Provider>
//             { children }
//         </CarsContext.Provider>
//     )
// }