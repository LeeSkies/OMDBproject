הקומפוננט חייב לקבל מערך של תמונות: images

הקומפוננט יכול לקבל קומפוננטים של חצים ולחצנים: Right, Left, Button

הקומפוננט יכול לקבל זמן לאנימציה - אלפיות שניה: Time

// <Slide
//  images={images}
//  Right={<hi2.HiChevronRight className='h-10 w-10' />}
//  Left={<hi2.HiChevronLeft className='h-10 w-10' />}
//  Time={3000}
// />

required packages: react-icons, tailwindcss

בשורה 18 אפשר לשנות את הרספונסיביות



@Maoz Schory